# API Reference

Tautulli API documentation has been moved to the [wiki page](https://github.com/Tautulli/Tautulli/wiki/Tautulli-API-Reference).